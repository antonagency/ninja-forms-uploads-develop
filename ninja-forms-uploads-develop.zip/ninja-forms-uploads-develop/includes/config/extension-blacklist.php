<?php if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Blacklisted File Extensions for Uploads
 */
return array(
    '.asp',
    '.apsx',
    '.bat',
    '.com',
    '.exe',
    '.jsp',
    '.php',
);
